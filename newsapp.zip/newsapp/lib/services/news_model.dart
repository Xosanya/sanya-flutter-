class news_model {
  // String? v;
  // late String b;

  late String author;
  late String title;
  late String description;
  late String url;
  late String URLToImage;
  late String publishedAt;
  late String content;

  news_model({
    required this.author,
    required this.title,
    required this.description,
    required this.url,
    required this.URLToImage,
    required this.publishedAt,
    required this.content,
  });

  news_model.extractFromJSOn(Map<String, dynamic> map) {
    author = map['author'] ?? "not avl";
    title = map['title'] ?? "not avl";
    description = map['description'] ?? "not avl";
    url = map['url'] ?? "not avl";
    URLToImage = map['urlToImage'] ?? "https://imgeng.jagran.com/images/2023/jan/cholebhature1674106312329.jpg";
    "https://imageio.forbes.com/specials-images/imageserve/6499ae7d51794529225d4176/2022-Toronto-International-Film-Festival---In-Conversation-With----Taylor-Swift/960x0.jpg?format=jpg&width=960";
    
    publishedAt = map['publishedAt'] ?? "not avl";
    content = map['content'] ?? "not avl";
  }
}

class Source {
  late String id;
  late String name;
  Source({required this.id, required this.name});

  Source.extractFromJSOn(Map<String, dynamic> map) {
    id = map['id'] ?? "not avl";
    name = map['name'] ?? "not avl";
  }
}
