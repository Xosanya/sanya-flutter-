// import 'package:flutter/material.dart';
// import 'package:youtube/services/ytmodel.dart';
// import 'package:youtube_player_flutter/youtube_player_flutter.dart';


// class VidPage extends StatefulWidget {
//   late List<YTModel> playList;
//   late int currInd;

//   VidPage({required this.playList, required this.currInd, super.key});

//   @override
//   State<VidPage> createState() => _VidPageState();
// }

// class _VidPageState extends State<VidPage> {
//   late YoutubePlayerController _controller;
//   @override
//   void initState() {
//     // String videoID = "I9zDTSAoYC8";
//     // String videoID = "jV7qK1kfD70";
//     _controller = YoutubePlayerController(
//       initialVideoId: widget.playList[widget.currInd].id,
//       flags: const YoutubePlayerFlags(
//         autoPlay: true,
//         // mute: true,
//       ),
//     );

//     // TODO: implement initState
//     super.initState();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return SafeArea(
//       child: Scaffold(
//         body: Container(
//           padding: EdgeInsets.symmetric(
//             vertical: 16,
//           ),
//           child: Column(
//             children: [
//               YoutubePlayer(
//                 controller: _controller,
//                 showVideoProgressIndicator: true,
//                 onReady: () {
//                   print("Video loaded...");
//                 },
//                 bottomActions: [
//                   CurrentPosition(),
//                   ProgressBar(
//                     isExpanded: true,
//                     colors: ProgressBarColors(
//                       playedColor: Colors.amber,
//                       handleColor: Colors.amber[100],
//                       backgroundColor: Colors.amber[50],
//                     ),
//                   ),
//                   RemainingDuration(),
//                   PlaybackSpeedButton(),
//                   FullScreenButton(),
//                   // PlayPauseButton(),
//                 ],
//               )
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }


import 'package:flutter/material.dart';
import 'package:youtube/services/ytmodel.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';


// ignore: must_be_immutable
class VideoPage extends StatefulWidget {
  late List<YTModel> playList;
  late int currentIndex;

  VideoPage({ required this.playList, required this.currentIndex,super.key});

  @override
  State<VideoPage> createState() => _VideoPageState();
}

class _VideoPageState extends State<VideoPage> {
  late YoutubePlayerController ytcontroller;
  @override
  void initState() {
    // TODO: implement initState
    
    ytcontroller = YoutubePlayerController(
      initialVideoId: widget.playList[widget.currentIndex].,
      flags: const YoutubePlayerFlags(
        autoPlay: true,)

    );
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return SafeArea(child: Scaffold(
      body: Container(
        padding: EdgeInsets.all(10),
      
      child: Column(
        children: [
          YoutubePlayer(controller: ytcontroller,
          showVideoProgressIndicator: true,
          onReady: () {
            print("video loaded");
          },
          bottomActions: [
            CurrentPosition(),
            ProgressBar(
              isExpanded: true,
              colors: ProgressBarColors(
                playedColor: Colors.red,
                handleColor: Colors.red,
                backgroundColor: Colors.white,
              ),
            ),
            RemainingDuration(),
            PlaybackSpeedButton(),
            FullScreenButton()
          ],
          )
        ],
      )
    )));
  }
}





