// // import 'package:dio/dio.dart';

// // class YTClient {
// //   Dio _dio = Dio();

// //   getData() async {
// //     String url =
// //         "https://youtube.googleapis.com/youtube/v3/videos?part=snippet%2CcontentDetails%2Cstatistics%2Cplayer&chart=mostPopular&maxResults=200&regionCode=IN&key=AIzaSyBSD8EfzTfzQvgFOo1dLob2enw-_rbS26E";

// //     try {
// //       Response resp = await _dio.get(url);
// //       return resp.data;
// //     } catch (err) {
// //       print("while fetching data\nfound: ${err}");
// //     }
// //   }
// // }
// import 'dart:convert';

// import 'package:dio/dio.dart';class youtubeClient {
//   final Dio dio = Dio();

//   Future<Map<String, dynamic>> getVideosFromYoutube() async {
//     try {
//       String youtubeUrl = "https://youtube.googleapis.com/youtube/v3/videos?part=snippet%2CcontentDetails%2Cstatistics%2Cplayer&chart=mostPopular&maxResults=200&regionCode=IN&key=%20AIzaSyCsUJX7IAnVtMlghfGjo7rYWRvfbku1yBI"; // Your API URL here
//       var res = await dio.get(youtubeUrl);
//       Map<String, dynamic> videoMap = jsonDecode(res.data);
//       return videoMap;
//     } catch (error) {
//       print("Error has occurred: $error");
//       return {}; // Return an empty map to handle errors
//     }
//   }
// }
import 'package:dio/dio.dart';

class YTClient {
  Dio dio = Dio();

  getytDataFromAPI() async {
    String ytURL =
        "https://youtube.googleapis.com/youtube/v3/videos?part=snippet%2CcontentDetails%2Cstatistics%2Cplayer&chart=mostPopular&maxResults=200&regionCode=IN&key=%20AIzaSyCr0s2hzyYXvPjrs6LO5pXA0J3IYPcuyAg";
    try {
      var response = await dio.get(ytURL);
      print("this is the youtube data from the API ${response.data}");
      return response.data;
    } catch (error) {
      print("Error in fetchind data from API");
    }
  }
}
//[0]['items'][0]['snippet'][0]['thumbnails'][0] ['default'][0]['url']