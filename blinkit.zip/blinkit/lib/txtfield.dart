import 'package:flutter/material.dart';

class textfield2 extends StatelessWidget {
  const textfield2({super.key});

  @override
  Widget build(BuildContext context) {
    return const TextField(
      decoration: InputDecoration(
        hintText: "Search Fot Sugar",
        fillColor: Color.fromARGB(255, 235, 235, 235),
        filled: true,
        prefixIcon: Icon(Icons.search,color: Colors.black),
        suffixIcon: Icon(
          Icons.mic,
          color: Colors.black,
          ),
          border: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(20))
          ),

      ),
    );
  }
}
