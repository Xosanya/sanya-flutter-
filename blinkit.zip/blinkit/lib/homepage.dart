
// import 'package:flutter/material.dart';

// class HomeScreen extends StatefulWidget {
//   const HomeScreen({super.key});

//   @override
//   State<HomeScreen> createState() => _HomeScreenState();
// }

// class _HomeScreenState extends State<HomeScreen> {
//   @override
//   Widget build(BuildContext context) {
//     return SafeArea(
//       child: Scaffold(
//         body: Column(
//           children: [
//             Padding(
//               padding: const EdgeInsets.all(10.0),
//               child: TextField(
//                 decoration: InputDecoration( hintText: "Search For Sugar", 
//                   fillColor: Color.fromARGB(255, 235, 235, 255),
//                   filled: true,
//                    prefixIcon: Icon(Icons.search,color: Colors.black,),
//                    suffixIcon: Icon(Icons.mic,color: Colors.black,),
//                    border: OutlineInputBorder(
//                     borderSide: BorderSide.none,
//                     borderRadius: BorderRadius.all(Radius.circular(20))
//                    )),
//               ),
//             ),
//             SizedBox(
//               height: MediaQuery.of(context).size.height*0.4,
//               width: MediaQuery.of(context).size.width,
//               child: ListView(
//                 scrollDirection: Axis.horizontal,
//                 children: [Stack(),Stack(),Stack()],
              
//               ),
//             )
//           ],
//         ),
//       ),
//     );
//   }
// }
import 'package:blinkit/bannerstack.dart';
import 'package:blinkit/bannerstack2.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class HomePage extends StatefulWidget {
  HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
  List<String> bannerImages = [
    'assets/banner1.jpg',
    'assets/banner2.jpg',
    'assets/p1.png',
    'assets/p2.png',
    'assets/p3.png',
    'assets/p4.png',
    'assets/p5.png',
    'assets/p6.png',
  ];
  List<Widget> getBannerStacks() {
    return bannerImages.map((imagePath) {
      return BannerStack(imageAssetPath: imagePath);
    }).toList();
  }
}

@override
State<HomePage> createState() => _HomePageState();
List<String> bannerImages2 = [
  'assets/banner1.jpg',
  'assets/banner2.jpg',
  'assets/p1.png',
  'assets/p2.png',
  'assets/p3.png',
  'assets/p4.png',
  'assets/p5.png',
  'assets/p6.png',
];
List<Widget> getBannerStacks() {
  return bannerImages2.map((imagePath) {
    return BannerStack2(imageAssetPath: imagePath);
  }).toList();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsetsDirectional.all(8.0),
              child: TextField(
                  decoration: InputDecoration(
                hintText: "search for sugar",
                fillColor: Colors.blue[100],
                filled: true,
                suffixIcon: const Icon(
                  Icons.mic,
                  color: Colors.black,
                ),
                border: OutlineInputBorder(
                    borderSide: BorderSide.none,
                    borderRadius: BorderRadius.circular(20)),
              )),
            ),
            Padding(
                padding: const EdgeInsets.all(10.0),
                child: SizedBox(
                    height: MediaQuery.of(context).size.height * 0.25,
                    child: ListView(
                        scrollDirection: Axis.horizontal,
                        children: const [
                          BannerStack(
                            imageAssetPath: 'assets/banner1.jpg',
                          ),
                          BannerStack(
                            imageAssetPath: 'assets/banner2.jpg',
                          ),
                          BannerStack(
                            imageAssetPath: 'assets/banner1.jpg',
                          ),
                        ]))),
            const SizedBox(
              height: 30,
            ),
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.only(left: 80.0),
                  child: const Column(
                    children: [
                      Text(
                        "SUPER INDEPENDENCE SALE ",
                        style: TextStyle(
                            fontSize: 25,
                            color: Color.fromARGB(255, 3, 12, 138),
                            fontWeight: FontWeight.bold),
                      ),
                      Chip(label: Text("EXPLORE NOW"))
                    ],
                  ),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: SizedBox(
                  height: MediaQuery.of(context).size.height * 0.25,
                  child: ListView(
                    physics: const BouncingScrollPhysics(),
                    scrollDirection: Axis.horizontal,
                    children: const [
                      BannerStack2(
                        imageAssetPath: 'assets/p6.png',
                      ),
                      BannerStack2(
                        imageAssetPath: 'assets/p5.png',
                      ),
                      BannerStack2(
                        imageAssetPath: 'assets/p4.png',
                      ),
                      BannerStack2(
                        imageAssetPath: 'assets/p3.png',
                      ),
                      BannerStack2(
                        imageAssetPath: 'assets/p2.png',
                      ),
                      BannerStack2(
                        imageAssetPath: 'assets/p1.png',
                      ),
                    ],
                  )),
            ),
            const SizedBox(
              height: 30,
            ),
            const Row(
              children: [
                Padding(
                  padding: EdgeInsets.only(left: 8.0),
                  child: Text(
                    "Shop by category",
                    style: TextStyle(
                        fontSize: 15,
                        color: Colors.black,
                        fontWeight: FontWeight.bold),
                  ),
                ),
                // Spacer(),
                // Chip(label: Text("SEE MORE"))
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: SizedBox(
                  height: MediaQuery.of(context).size.height * 0.25,
                  child: ListView(
                    physics: const BouncingScrollPhysics(),
                    scrollDirection: Axis.horizontal,
                    children: const [
                      BannerStack2(
                        imageAssetPath: 'assets/p1.png',
                      ),
                      BannerStack2(
                        imageAssetPath: 'assets/p2.png',
                      ),
                      BannerStack2(
                        imageAssetPath: 'assets/p3.png',
                      ),
                      BannerStack2(
                        imageAssetPath: 'assets/p4.png',
                      ),
                      BannerStack2(
                        imageAssetPath: 'assets/p5.png',
                      ),
                      BannerStack2(
                        imageAssetPath: 'assets/p6.png',
                      ),
                    ],
                  )),
            ),
          ],
        ),
      ),
    ));
  }
}
