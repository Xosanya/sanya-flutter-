
// import 'package:blinkit/roundrect.dart';
// import 'package:flutter/material.dart';

// class HomeStack extends StatefulWidget {
//   String? title;
//   String? subtitle;
//   String? imageUrl;
//   HomeStack(
//       {this.title = "Hair Oils for\nlong & thick hair",
//       this.subtitle,
//       this.imageUrl =
//           "https://th.bing.com/th/id/OIP.1S3cpbLJSc37EjA33esKmQHaE8?pid=ImgDet&rs=1",
//       super.key});

//   @override
//   State<HomeStack> createState() => _HomeStackState();
// }

// class _HomeStackState extends State<HomeStack> {
//   @override
//   Widget build(BuildContext context) {
//     return Padding(
//       padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 0),
//       child: Stack(
//         children: [
//           // RoundRectImage(),
//           Container(
//             width: MediaQuery.of(context).size.width,
//             height: MediaQuery.of(context).size.height,
//             // child: Image.network(
//             //   "https://th.bing.com/th/id/OIP.1S3cpbLJSc37EjA33esKmQHaE8?pid=ImgDet&rs=1",
//             //   fit: BoxFit.cover,
//             // ),
//             child: RoundRectImage(
//               imagePath: widget.imageUrl,
//             ),
//             decoration: BoxDecoration(
//               color: Colors.amber[100],
//               borderRadius: BorderRadius.circular(15),
//             ),
//           ),
//           Positioned(
//             left: MediaQuery.of(context).size.width * 0.052,
//             top: MediaQuery.of(context).size.height * 0.02,
//             child: Text(
//               widget.title!,
//               style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
//             ),
//           ),
//           Positioned(
//             left: MediaQuery.of(context).size.width * 0.052,
//             top: MediaQuery.of(context).size.height * 0.132,
//             child: Text(
//               widget.subtitle!,
//               style: TextStyle(
//                 fontSize: 15,
//               ),
//             ),
//           ),
//           Positioned(
//             left: MediaQuery.of(context).size.width * 0.052,
//             bottom: MediaQuery.of(context).size.height * 0.025,
//             child: Padding(
//               padding: const EdgeInsets.all(8.0),
//               child: TextButton(
//                 onPressed: () {},
//                 child: Text("Shop Now"),
//                 style: ButtonStyle(
//                   backgroundColor: MaterialStateProperty.all(Colors.black),
//                   foregroundColor: MaterialStateProperty.all(Colors.amber[100]),
//                 ),
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }
import 'package:flutter/material.dart';

class BannerStack extends StatefulWidget {
  final String imageAssetPath;
  const BannerStack({super.key, required this.imageAssetPath});

  @override
  State<BannerStack> createState() => _BannerStackState();
}

class _BannerStackState extends State<BannerStack> {
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
            height: MediaQuery.of(context).size.height * 0.3,
            width: MediaQuery.of(context).size.width * 0.8,
            color: Colors.blue,
            child: Image.asset(
              widget.imageAssetPath,
              fit: BoxFit.cover,
            )),
        const Positioned(
          top: 15,
          left: 10,
          child: Text(
            "Buy 2 get 1 free!!!",
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
        ),
        const Positioned(
          top: 40,
          left: 10,
          child: Text(
            "Terms & Conditions applied",
            style: TextStyle(fontSize: 10),
          ),
        ),
        Positioned(
            bottom: 10,
            left: 10,
            child: TextButton(
              onPressed: () {},
              child: const Text(
                "SHOP NOW",
                style: TextStyle(color: Colors.black),
              ),
            )),
      ],
    );
  }
}

