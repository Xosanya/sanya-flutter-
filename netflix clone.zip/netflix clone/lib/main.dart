import 'package:flutter/material.dart';
import 'package:newproject/widgets/navbar.dart';
 import 'screens/homepage.dart';
void main(){
  runApp ( const MaterialApp(
    home: NavBar()

  ));
}
