
import 'package:flutter/material.dart';

class COUNTER extends StatefulWidget {
  const COUNTER({super.key});

  @override
  State<COUNTER> createState() => _COUNTERState();
}

class _COUNTERState extends State<COUNTER>{
int count =0;
@override
Widget build(BuildContext context){
  return Scaffold(
    floatingActionButton: FloatingActionButton(
      onPressed: (){
        count++;
        print("this is our current count $count");
        setState(() {});

      },
      child: const Text(
        "this is the count",
        style:TextStyle(color :Colors.white,fontSize:30),
        
      ),
      // Text(
      //   "COUNT: ${count.toString()}"
      // ),
      
    ) ,
  );
}
    
  // late AnimationController _controller;

  // @override
  // void initState() {
  //   super.initState();
  //   _controller = AnimationController(vsync: this);
  // }

  // @override
  // void dispose() {
  //   _controller.dispose();
  //   super.dispose();
  // }

  // @override
  // Widget build(BuildContext context) {
  //   return const Placeholder();
  // }
}