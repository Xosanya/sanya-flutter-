import 'package:flutter/material.dart';
import 'package:newproject/widgets/mylist1.dart';
import 'package:newproject/widgets/netflixoriginal.dart';
import 'package:newproject/widgets/nf_stack.dart';
import 'package:newproject/widgets/preview.dart';

class homepage extends StatefulWidget {
  const homepage({super.key});

  @override
  State<homepage> createState() => _homepage();
}

class _homepage extends State<homepage> with SingleTickerProviderStateMixin {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        leading: Image.asset("assets/netflix_logo0.png"),
        actions: [
          OutlinedButton(
              onPressed: () {},
              child: const Text(
                "TV shows",
                style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
              )),
          // Padding(padding: EdgeInsets.all(8.0)),
          // Text(
          //   "TV shows",
          //   style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold),
          // ),
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: GestureDetector(
              onTap: () {},
              child: const Text(
                "Movies",
                style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
              ),
            ),
          ),
          const Padding(
            padding: EdgeInsets.all(10.0),
            child: Text(
              "My List",
              style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
      
      body: SingleChildScrollView(
        child: Container(
            color: Colors.black,
            //width: double.infinity,
            //height: double.infinity,
            child:  Column(
              children: [NFSTACK(), PREVIEW(), MYLIST1(),NETFLIXORIGINAL(),
               ],
            )),
      ),
    ));
  }
}
