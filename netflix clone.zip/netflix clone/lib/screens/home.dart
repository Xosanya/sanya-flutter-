import 'package:flutter/material.dart';

class home extends StatelessWidget {
  const home({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
        child: Text(
          "Home",
          style: TextStyle( fontSize: 40, fontWeight: FontWeight.bold ),),
      ),
    );

  }
}