import 'package:flutter/material.dart';

import 'package:newproject/widgets/profile.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.black,
           leading: const Row(
                children: [
                  SizedBox(
                    width: 20,
                  ),
                  
                ],
              ),
              title: const Text(
                "Profiles And More ",
                style:
                    TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
              ),
        ),
        body: SingleChildScrollView(
        child: Container(
            color: Colors.black,
            //width: double.infinity,
            //height: double.infinity,
            child:  Column(
              children: [manageprofile(),
               ],
            )),
      ),
    ));


     
      
    
    
  }
}
