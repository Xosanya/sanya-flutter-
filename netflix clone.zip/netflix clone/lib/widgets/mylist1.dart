import 'package:flutter/material.dart';

class MYLIST1 extends StatefulWidget {
  const MYLIST1({super.key});

  @override
  State<MYLIST1> createState() => _MYLIST1State();
}

class _MYLIST1State extends State<MYLIST1> {
  @override
  Widget build(BuildContext context) {
    return Column( crossAxisAlignment: CrossAxisAlignment.start,
      children: [Text("My List", style: TextStyle(fontSize: 20, color: Colors.white, fontWeight: FontWeight.bold ),
      ),
      SizedBox(height: 10,),
      Container(
        
        width: double.infinity,
        height: 200,
      
        child: ListView(
          scrollDirection: Axis.horizontal,
          children: [Padding(padding: EdgeInsets.all(2.0),
                child: Container(
                  width: 100,
                  height: 200,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    image: const DecorationImage(
                      image: AssetImage("assets/bollywood6.jpg"),
                      fit: BoxFit.cover,
          ), 
                  ),
                ),
          ),
          Padding(padding: EdgeInsets.all(2.0),
          child: Container(
                  width: 100,
                  height: 200,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    image: const DecorationImage(
                      image: AssetImage("assets/bollywood7.jpg"),
                      fit: BoxFit.cover,
          ), 
                  ),
                ),
          ),
            
        
          
          Padding(padding: EdgeInsets.all(2.0),
           child: Container(
                  width: 100,
                  height: 200,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    image: const DecorationImage(
                      image: AssetImage("assets/bollywood9.jpg"),
                      fit: BoxFit.cover,
          ), 
                  ),
                ),
          ),
          
          Padding(padding: EdgeInsets.all(2.0),
              child: Container(
                  width: 100,
                  height: 200,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    image: const DecorationImage(
                      image: AssetImage("black_mirror.jpg"),
                      fit: BoxFit.cover,
          ), 
                  ),
                ),
          ),
            
        
          Padding(padding: EdgeInsets.all(2.0),

             child: Container(
                  width: 100,
                  height: 200,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    image: const DecorationImage(
                      image: AssetImage("assets/OFFICIAL.png"),
                      fit: BoxFit.cover,
          ), 
                  ),
                ),
          ),
            
        
          Padding(padding: EdgeInsets.all(2.0),
            child: Container(
                  width: 100,
                  height: 200,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    image: const DecorationImage(
                      image: AssetImage("assets/carole.jpg"),
                      fit: BoxFit.cover,
                        ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
                    