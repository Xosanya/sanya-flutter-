// import 'package:flutter/material.dart';

// class manageprofile extends StatelessWidget {
//   const manageprofile({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         const Text(
//           "Manage Profiles",
//           style: TextStyle(
//               fontSize: 20, color: Colors.white, fontWeight: FontWeight.bold),
//         ),
//         const Icon(Icons.edit),
//         const SizedBox(
//           height: 10,
//         ),
//         SizedBox(
//           width: double.infinity,
//           height: 100,
//           child: ListView(
//             scrollDirection: Axis.horizontal,
//             children: [
//               Padding(
//                 padding: const EdgeInsets.all(6.0),
//                 child: Container(
//                   width: 100,
//                   height: 100,
    
//                   decoration: BoxDecoration(
//                     borderRadius: BorderRadius.circular(8),
//                     image: const DecorationImage(
//                       image: AssetImage("assets/p1.png"),
//                       fit: BoxFit.cover,
//                     ),
//                   ),
//                 ),
//               ),
              
//               Padding(
//                 padding: const EdgeInsets.all(6.0),
//                 child: Container(
//                   width: 100,
//                   height: 100,
//                   decoration: BoxDecoration(
//                     borderRadius: BorderRadius.circular(8),
//                     image: const DecorationImage(
//                       image: AssetImage("assets/p2.png"),
//                       fit: BoxFit.cover,
//                     ),
//                   ),
//                 ),
//               ),
//               Padding(
//                 padding: const EdgeInsets.all(6.0),
//                 child: Container(
//                   width: 100,
//                   height: 100,
//                   decoration: BoxDecoration(
//                     borderRadius: BorderRadius.circular(8),
//                     image: const DecorationImage(
//                       image: AssetImage("assets/p3.png"),
//                       fit: BoxFit.cover,
//                     ),
//                   ),
//                 ),
//               ),
//               Padding(
//                 padding: const EdgeInsets.all(6.0),
//                 child: Container(
//                   width: 100,
//                   height: 100,            
//                   decoration: BoxDecoration(
//                     // children: [
//                     //   Text(
//                     //     "Age",
//                     //     style: TextStyle(color: Colors.black, fontSize: 20),)
//                     // ]
//                     borderRadius: BorderRadius.circular(8),
//                     image: const DecorationImage(
//                       image: AssetImage("assets/p4.png"),
//                       fit: BoxFit.cover,
                   
//                     ),
//                   ),
//                 ),
//               ),
              
//               Padding(
//                 padding: const EdgeInsets.all(6.0),
//                 child: Container(
//                   width: 100,
//                   height: 100,
//                   decoration: BoxDecoration(
//                     borderRadius: BorderRadius.circular(8),
//                     image: const DecorationImage(
//                       image: AssetImage("assets/p5.png"),
//                       fit: BoxFit.cover,
//                     ),
//                   ),
//                 ),
//               ),
//                 const SizedBox(height: 50),
//             Container(
//               width: 400,
//               height: 50,
//               color: const Color.fromARGB(255, 51, 51, 51),
//               child: const Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceBetween,

//                 children: [
//                   Padding(
//                     padding: EdgeInsets.only(left: 16.0),
//                     child: Icon(
//                       Icons.notification_add,
//                       color: Colors.white,
//                     ),
//                   ),
//                   SizedBox(width: 10), // Add some space between the icon and the text
//                   Text(
//                     'Notification',
//                     style: TextStyle(fontSize: 20, color: Colors.white),
//                   ),
//                   Padding(
//                     padding: EdgeInsets.only(left: 16.0),
//                     child: Icon(
//                       Icons.slideshow,
//                       color: Colors.white,
                      
                      
//                     ),
//                   ),

//                 ],
//               ),
//             ),
//             SizedBox(height: 10),

//             // mylist
//             Container(
//               width: 400,
//               height: 50,
//               color: const Color.fromARGB(255, 51, 51, 51),
//               child: const Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceBetween,

//                 children: [
//                   Padding(
//                     padding: EdgeInsets.only(left: 16.0),
//                     child: Icon(
//                       Icons.list,
//                       color: Colors.white,
//                     ),
//                   ),
//                   SizedBox(width: 10), // Add some space between the icon and the text
//                   Text(
//                     'My List',
//                     style: TextStyle(fontSize: 20, color: Colors.white),
//                   ),
                  
//                   Padding(
//                     padding: EdgeInsets.only(left: 16.0),
//                     child: Icon(
//                       Icons.slideshow,
//                       color: Colors.white,
                      
                      
//                     ),
//                   ),

//                 ],
//               ),
//             ),
//             SizedBox(height: 10),

//             // app setting
//             Container(
//               width: 400,
//               height: 50,
//               color: const Color.fromARGB(255, 51, 51, 51),
//               child: const Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceBetween,

//                 children: [
//                   Padding(
//                     padding: EdgeInsets.only(left: 16.0),
//                     child: Icon(
//                       Icons.settings,
//                       color: Colors.white,
//                     ),
//                   ),
//                   SizedBox(width: 10), // Add some space between the icon and the text
//                   Text(
//                     'App settings',
//                     style: TextStyle(fontSize: 20, color: Colors.white),
//                   ),
//                   Padding(
//                     padding: EdgeInsets.only(left: 16.0),
//                     child: Icon(
//                       Icons.slideshow,
//                       color: Colors.white,
                      
                      
//                     ),
//                   ),

//                 ],
//               ),
//             ),
//             SizedBox(height: 10),
//             //account

//             Container(
//               width: 400,
//               height: 50,
//               color: const Color.fromARGB(255, 51, 51, 51),
//               child: const Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceBetween,

//                 children: [
//                   Padding(
//                     padding: EdgeInsets.only(left: 16.0),
//                     child: Icon(
//                       Icons.account_box,
//                       color: Colors.white,
//                     ),
//                   ),
//                   SizedBox(width: 10), // Add some space between the icon and the text
//                   Text(
//                     'account',
//                     style: TextStyle(fontSize: 20, color: Colors.white),
//                   ),
//                   Padding(
//                     padding: EdgeInsets.only(left: 16.0),
//                     child: Icon(
//                       Icons.slideshow,
//                       color: Colors.white,
                      
                      
//                     ),
//                   ),

//                 ],
//               ),
//             ),
//             SizedBox(height: 10),
//             // help

//             Container(
//               width: 400,
//               height: 50,
//               color: const Color.fromARGB(255, 51, 51, 51),
//               child: const Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceBetween,

//                 children: [
//                   Padding(
//                     padding: EdgeInsets.only(left: 16.0),
//                     child: Icon(
//                       Icons.help,
//                       color: Colors.white,
//                     ),
//                   ),
//                   SizedBox(width: 10), // Add some space between the icon and the text
//                   Text(
//                     'help',
//                     style: TextStyle(fontSize: 20, color: Colors.white, ),
//                   ),
//                   Padding(
//                     padding: EdgeInsets.only(left: 16.0),
//                     child: Icon(
//                       Icons.slideshow,
//                       color: Colors.white,
                      
                      
//                     ),
//                   ),

//                 ],
//               ),
//             ),
//             SizedBox(height: 20,),
//             Container(
//   width: 300,
//   height: 100,
//   child: Padding(
//     padding: EdgeInsets.only(left: 110, right: 110), 
//     child: Text(
//       "Sign Out",
//       style: TextStyle(fontSize: 20, color: Colors.white),
//     ),
//   ),
// ),

//           ],
          

//         ),
//       ),
    
//       ]
//     );
//   }
// }

// class SquareAvatar extends StatelessWidget {
//   final double size;
//   final ImageProvider<Object> backgroundImage;

//   const SquareAvatar({super.key, 
//     required this.size,
//     required this.backgroundImage,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       width: size,
//       height: size,
//       decoration: BoxDecoration(
//         borderRadius: BorderRadius.circular(8),
//         image: DecorationImage(
//           image: backgroundImage,
//           fit: BoxFit.cover,
//         ),
//       ),
//     );
         
    
    
     
//   }
// }

import 'package:flutter/material.dart';

class manageprofile extends StatelessWidget {
  const manageprofile({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "Manage Profiles",
          style: TextStyle(
            fontSize: 20,
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        const Icon(Icons.edit),
        const SizedBox(
          height: 10,
        ),
        SizedBox(
          width: double.infinity,
          height: 100,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: [
              Padding(
                padding: const EdgeInsets.all(6.0),
                child: Container(
                  width: 100,
                  height: 100,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    image: const DecorationImage(
                      image: AssetImage("assets/p1.png"),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(6.0),
                child: Container(
                  width: 100,
                  height: 100,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    image: const DecorationImage(
                      image: AssetImage("assets/p2.png"),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(6.0),
                child: Container(
                  width: 100,
                  height: 100,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    image: const DecorationImage(
                      image: AssetImage("assets/p3.png"),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(6.0),
                child: Container(
                  width: 100,
                  height: 100,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    image: const DecorationImage(
                      image: AssetImage("assets/p4.png"),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(6.0),
                child: Container(
                  width: 100,
                  height: 100,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    image: const DecorationImage(
                      image: AssetImage("assets/p5.png"),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 50),
        // Notification
        Container(
          width: 400,
          height: 50,
          color: const Color.fromARGB(255, 51, 51, 51),
          child: const Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Padding(
                padding: EdgeInsets.only(left: 16.0),
                child: Icon(
                  Icons.notification_add,
                  color: Colors.white,
                ),
              ),
              SizedBox(width: 10),
              Text(
                'Notification',
                style: TextStyle(fontSize: 20, color: Colors.white),
              ),
              Padding(
                padding: EdgeInsets.only(left: 16.0),
                child: Icon(
                  Icons.slideshow,
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 10),
        // My List
        Container(
          width: 400,
          height: 50,
          color: const Color.fromARGB(255, 51, 51, 51),
          child: const Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Padding(
                padding: EdgeInsets.only(left: 16.0),
                child: Icon(
                  Icons.list,
                  color: Colors.white,
                ),
              ),
              SizedBox(width: 10),
              Text(
                'My List',
                style: TextStyle(fontSize: 20, color: Colors.white),
              ),
              Padding(
                padding: EdgeInsets.only(left: 16.0),
                child: Icon(
                  Icons.slideshow,
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 10),
        // App Settings
        Container(
          width: 400,
          height: 50,
          color: const Color.fromARGB(255, 51, 51, 51),
          child: const Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Padding(
                padding: EdgeInsets.only(left: 16.0),
                child: Icon(
                  Icons.settings,
                  color: Colors.white,
                ),
              ),
              SizedBox(width: 10),
              Text(
                'App settings',
                style: TextStyle(fontSize: 20, color: Colors.white),
              ),
              Padding(
                padding: EdgeInsets.only(left: 16.0),
                child: Icon(
                  Icons.slideshow,
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 10),
        // Account
        Container(
          width: 400,
          height: 50,
          color: const Color.fromARGB(255, 51, 51, 51),
          child: const Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Padding(
                padding: EdgeInsets.only(left: 16.0),
                child: Icon(
                  Icons.account_box,
                  color: Colors.white,
                ),
              ),
              SizedBox(width: 10),
              Text(
                'account',
                style: TextStyle(fontSize: 20, color: Colors.white),
              ),
              Padding(
                padding: EdgeInsets.only(left: 16.0),
                child: Icon(
                  Icons.slideshow,
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 10),
        // Help
        Container(
          width: 400,
          height: 50,
          color: const Color.fromARGB(255, 51, 51, 51),
          child: const Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Padding(
                padding: EdgeInsets.only(left: 16.0),
                child: Icon(
                  Icons.help,
                  color: Colors.white,
                ),
              ),
              SizedBox(width: 10),
              Text(
                'help',
                style: TextStyle(fontSize: 20, color: Colors.white),
              ),
              Padding(
                padding: EdgeInsets.only(left: 16.0),
                child: Icon(
                  Icons.slideshow,
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 20),
        Container(
          width: 300,
          height: 100,
          child: Padding(
            padding: EdgeInsets.only(left: 110, right: 110),
            child: Text(
              "Sign Out",
              style: TextStyle(fontSize: 20, color: Colors.white),
            ),
          ),
        ),
      ],
    );
  }
}

class SquareAvatar extends StatelessWidget {
  final double size;
  final ImageProvider<Object> backgroundImage;

  const SquareAvatar({
    super.key,
    required this.size,
    required this.backgroundImage,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        image: DecorationImage(
          image: backgroundImage,
          fit: BoxFit.cover,
        ),
      ),
    );
  }
}

