import 'package:flutter/material.dart';

class itemContainer extends StatelessWidget {
  Color containerColor;
  String textData;
  itemContainer({super.key,required this.containerColor,required this.textData});
 
  Widget build(BuildContext context){
    return Container(
      height: 200,
      width:100,
      decoration: BoxDecoration(
        color: containerColor,
        border:Border.all(width:2),
        borderRadius: const BorderRadius.all(Radius.circular(20))),
      child: Center(
          child: Text(
            textData,
            style:const TextStyle(color: Colors.white),

          )),
      );
  
  }
}

// class _MyWidgetState extends State<MyWidget>
//     with SingleTickerProviderStateMixin {
//   late AnimationController _controller;

//   @override
//   void initState() {
//     super.initState();
//     _controller = AnimationController(vsync: this);
//   }

//   @override
//   void dispose() {
//     _controller.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return const Placeholder();
//   }
// }