

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class LOGINPAGE extends StatefulWidget {
  const LOGINPAGE({super.key});

  @override
  State<LOGINPAGE> createState() => _LOGINPAGEState();
}

class _LOGINPAGEState extends State<LOGINPAGE> {
  TextEditingController ttt = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
          body: Column(
        children: [
          TextField(
            controller: ttt,
            obscureText: true,
            decoration: InputDecoration(
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.all(Radius.circular(50))),
              prefixIcon: const Icon(Icons.search),
            ),
          ),
          TextField(
            controller: ttt,
            obscureText: true,
            decoration: InputDecoration(
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.all(Radius.circular(50))),
            ),
          ),
          Text(
            "Hii its me again!!",
            style: GoogleFonts.anonymousPro(fontSize: 40),
          ),
          SizedBox(
            height: 200,
            width: 200,
            child: Container(
              decoration: BoxDecoration(
                  gradient: RadialGradient(colors: [
                    Colors.yellow,
                    Color.fromARGB(255, 14, 94, 16),
                    Color.fromARGB(255, 3, 34, 60)
                  ]),
                  borderRadius: BorderRadius.circular(30)),

              // child: Card(color: Colors.pink,elevation:20,shadowColor: Colors.purple,)
            ),
          ),
          const Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
          const Chip(
            label: Text("I"),
            avatar: CircleAvatar(child: Text("🤡")),
            deleteIcon: Icon(Icons.delete),
            deleteIconColor: Colors.red,
          ),
          const Chip(
            label: Text("am"),
            avatar: CircleAvatar(child: Text("🤡")),
            deleteIcon: Icon(Icons.delete),
            deleteIconColor: Colors.red,
          ),
          const Chip(
            label: Text("a fking"),
            avatar: CircleAvatar(child: Text("🤡")),
            deleteIcon: Icon(Icons.delete),
            deleteIconColor: Colors.red,
          ),
          const Chip(
            label: Text("clown"),
            avatar: CircleAvatar(child: Text("  !!")),
            deleteIcon: Icon(Icons.delete),
            deleteIconColor: Colors.red,
          )]
          ),
        ],
      )),
    );
  }
}
